from controller import Controller
from sr import *

cont = Controller(Robot())
cont.main()
