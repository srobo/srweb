from controller import Controller
from sr import *

cont = Controller(Robot(init_vision = False))
cont.main()
